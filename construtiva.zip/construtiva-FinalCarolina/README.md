<<<<<<< HEAD
# Welcome to your Expo app 👋

# prjConstrutiva
=======
# construtiva
Repositório para versionarmos nosso projeto
>>>>>>> 42778b9206e2063f163dc6e020dfc44c4308567f
